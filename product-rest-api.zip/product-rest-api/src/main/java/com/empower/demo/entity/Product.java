package com.empower.demo.entity;


public class Product {
	private Long id;
	private String name;
	private Double price;
	private Category category;
	
	
}
