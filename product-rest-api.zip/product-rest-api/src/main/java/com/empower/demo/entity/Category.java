package com.empower.demo.entity;

import java.util.List;

public class Category {
	private Long id;
	private String name;
	private List<Product> products;
	
}
